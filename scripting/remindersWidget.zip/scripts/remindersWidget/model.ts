import { Notification, Script, LiveActivity } from 'scripting'
import { config } from "./config"
import { loadRecords, saveRecords } from './store'

const fileName = 'Model'

export async function getReminders(options: {
    startDate?: Date,
    endDate?: Date,
    limit?: number,
    isCompleted?: boolean,
    calendarNames?: string[],
    ignoreStartDate?: boolean,
    ignoreEndDate?: boolean
} = {}) {
    const { startDate, endDate, limit = 1, isCompleted = false, calendarNames, ignoreStartDate, ignoreEndDate } = options;

    try {
        let calendars: Calendar[] = [];

        // 获取指定日历或默认日历
        if (calendarNames && calendarNames.length > 0) {
            const allReminderCals = await Calendar.forReminders();
            calendars = allReminderCals.filter(c => calendarNames.includes(c.title));

            if (calendars.length === 0) {
                notification(fileName, "未找到匹配的日历名称，退回默认日历", config.debug, false);
                const defaultCal = await Calendar.defaultForReminders();
                if (defaultCal) calendars = [defaultCal];
            } else {
                notification(fileName, `根据名称找到的提醒事项日历: ${calendars.map(c => c.title).join(", ")}`, config.debug, true);
            }
        }
        // else {
        //     const defaultCal = await Calendar.defaultForReminders();
        //     if (defaultCal) calendars = [defaultCal];
        //     else notification(fileName, "未找到默认提醒事项日历", config.debug, false);
        // }

        const now = new Date();
        let all: Reminder[] = [];

        if (isCompleted) {
            // 完成提醒使用 startDate 和 endDate
            const params: any = { calendars };
            if (!ignoreStartDate) params.startDate = startDate ?? new Date(now.getTime() - 1440 * 60000); // 默认1天前
            if (!ignoreEndDate) params.endDate = endDate ?? (() => {
                const tomorrow = new Date(now);
                tomorrow.setDate(now.getDate() + 1);
                tomorrow.setHours(3, 0, 0, 0);
                return tomorrow;
            })();

            all = await Reminder.getCompleteds(params);
        } else {
            // 未完成提醒通常只用 endDate
            const params: any = { calendars };
            if (!ignoreEndDate) params.endDate = endDate ?? (() => {
                const tomorrow = new Date(now);
                tomorrow.setDate(now.getDate() + 1);
                tomorrow.setHours(3, 0, 0, 0);
                return tomorrow;
            })();

            all = await Reminder.getIncompletes(params);
        }

        // 过滤有效日期提醒
        const filtered = all.filter(r => r.dueDateComponents?.date);

        // 按时间排序
        const sorted = filtered.sort((a, b) =>
            (a.dueDateComponents?.date?.getTime() ?? 0) - (b.dueDateComponents?.date?.getTime() ?? 0)
        );

        notification(fileName, `[Model] 获取到提醒条数: ${sorted.length}`, config.debug, true);
        return sorted.slice(0, limit);

    } catch (err) {
        notification(fileName, `[Model] 获取提醒异常: ${err}`, config.debug, false);
        return [];
    }
}



export function formatTime(date?: Date) {
    if (!date) return ""
    return `${date.getHours().toString().padStart(2, "0")}:${date.getMinutes()
        .toString()
        .padStart(2, "0")}`
}

export async function notification(
    subtitle: string,
    body: string,
    debug: boolean = false, // 是否仅打印日志
    isOK: boolean = true, // 是否成功
    options?: {
        title?: string,
        actions?: { title: string, scriptName: string, parameters?: Record<string, any>, destructive?: boolean }[], // 操作按钮
        trigger?: any, // 可传入时间/日历/位置触发器
        silent?: boolean,
        userInfo: Record<string, any>,
        interruptionLevel?: "active" | "passive" | "timeSensitive",
        avoidRunningCurrentScriptWhenTapped?: boolean
        customUI?: boolean
    }
) {
    const { actions = [], trigger = null, silent = false, interruptionLevel, avoidRunningCurrentScriptWhenTapped, userInfo, customUI } = options ?? {}
    const OK = isOK ? "✅" : "❌"

    if (debug) {
        await Notification.schedule({
            title: options?.title ?? config.name,
            subtitle: options ? subtitle : `${OK}${subtitle}`,
            body,
            threadIdentifier: subtitle,
            avoidRunningCurrentScriptWhenTapped,
            silent,
            interruptionLevel,
            trigger,
            userInfo,
            customUI,
            actions: actions.map(a => ({
                title: a.title,
                url: Script.createRunURLScheme(a.scriptName, a.parameters ?? {}),
                destructive: a.destructive
            }))
        })
    } else { console.log(`[Debug Notification] ${subtitle}: ${OK}${body}`) }
}

export async function startLiveActivity(params: { title: string; identifier: string; dueDate: string; notes?: string }) {
    try {
        notification(fileName, `尝试启动实时活动: ${params.title}`, config.debug, true)
        const now = new Date()
        const defaultDueDate = new Date(now.getTime() + 30 * 60_000)
        // const title = '测试实时活动,测试实时活动'
        // const identifier = `test-activity-${dueDateObj.getTime()}`
        let dueDateObj: Date
        if (params.dueDate) {
            dueDateObj = typeof params.dueDate === 'string' ? new Date(params.dueDate) : params.dueDate
            if (isNaN(dueDateObj.getTime())) dueDateObj = defaultDueDate
        } else {
            dueDateObj = defaultDueDate
        }
        if (dueDateObj < now) { dueDateObj = defaultDueDate } // 由于 TimerIntervalLabel 参数需要时间未到
        const liveActivity = await import("./live_activity") // 动态导入
        await liveActivity.startReminderActivity(params.title!, params.identifier!, dueDateObj, params.notes)
    } catch (err) {
        notification(fileName, `执行实时活动提醒异常: ${String(err)}`, config.debug, false)
    }
}

export function getDateInfo() {
    const now = new Date()
    // 公历日
    const day = now.getDate().toString()
    // 星期
    const weekday = ["周日", "周一", "周二", "周三", "周四", "周五", "周六"][now.getDay()]
    // // 农历（这里先写死，后面可接入 API）
    // const lunar = "初二"
    return { day, weekday }
}

// export async function clearUnreferencedLiveActivities() { // 如果手动清理的话,需要在App Intents中注册LiveActivityIntent,加载很慢,另外这个功能用处不是很大,在此禁用.
//     try {
//         const liveActivityIds = await LiveActivity.getAllActivitiesIds()
//         notification(fileName, `当前活动ID: ${liveActivityIds.join(", ")}`, config.debug, true)
//         let records = loadRecords()
//         const dRecord = records.filter(r => !liveActivityIds.includes(r.liveActivityId)) // 下面改成了saveRecords，这里的逻辑要注意
//         notification(fileName,
//             dRecord.length > 0 ?
//                 `需要清理实时活动\n数量：${dRecord.length}\nID: ${dRecord.map(r => r.liveActivityId).join(", ")}`
//                 : `无需清理实时活动`
//             , config.debug, true)
//         if (dRecord.length) saveRecords(dRecord)
//     } catch (err) {
//         notification(fileName, `清理未引用实时活动异常: ${String(err)}`, config.debug, false)
//     }
// }
