export const config = {
    version: "1.0.1", // 小组件版本号
    name: "Reminders Widget", // 小组件名称
    description: "一个用于显示提醒事项的小组件",
    log: '250828: 修复提醒事项获取逻辑',
    debug: false, // 是否启用调试模式
    maxLiveActivityCount: 3, // 最大实时活动数量，超过后会替换最旧的活动
    liveActivityDismissTimeInterval: 30, // 实时活动自动消失时间间隔（秒）
    widgetTimerInterval: 30 // 小组件显示倒计时或开始时间时间间隔（分钟）
}
