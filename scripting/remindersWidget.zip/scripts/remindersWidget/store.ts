const storageKey = "liveActivity.records"

export type RecordInfo = {
  reminderId: string
  liveActivityId: string
}

export function loadRecords() { // 加载记录
  return Storage.get<RecordInfo[]>(storageKey) ?? []
}

export function saveRecords(value: RecordInfo[]) { // 保存记录
  Storage.set(storageKey, value)
}

// export function deleteRecords(value: RecordInfo[]): void {
//   let records = loadRecords()

//   // 过滤掉要删除的记录（匹配 reminderId 和 liveActivityId）
//   records = records.filter(r =>
//     !value.some(v =>
//       v.reminderId === r.reminderId &&
//       v.liveActivityId === r.liveActivityId
//     )
//   )

//   saveRecords(records) // 更新存储
// }
