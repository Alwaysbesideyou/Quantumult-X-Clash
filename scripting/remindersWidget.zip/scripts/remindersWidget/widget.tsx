import { VStack, HStack, Text, Button, Widget, gradient, Spacer, Rectangle, Link, Image, Toggle } from "scripting"
import { testNotify, widgetReloadAll, CompleteReminderIntent, startLiveActivityButton } from "./app_intents"
import { getReminders, getDateInfo } from "./model"
import { loadRecords, saveRecords } from './store'

const fileName = 'Widget'

export async function ReminderWidgetView() {
  try {
    const reminders = await getReminders({ limit: 5, isCompleted: false })
    const now = new Date()
    const displayReminders = reminders.slice(0, 3);
    const { day, weekday } = getDateInfo()
    const records = loadRecords()

    return (
      <VStack
        alignment={"leading"}
        frame={{ maxWidth: Infinity, maxHeight: Infinity, alignment: "topLeading" }}
        widgetBackground={{
          dark: gradient("linear", {
            colors: ["#2C2C2EFF", "#1C1C1EFF"],
            startPoint: "top",
            endPoint: "bottom",
          }),
          light: gradient("linear", {
            colors: ["#FFFFFF00", "#F2F2F7FF"],
            startPoint: "top",
            endPoint: "bottom",
          })
        }}
      >
        {/* 固定标题栏 */}
        <HStack alignment={"center"} padding={{ top: 8, bottom: 0 }}>
          {/* <Link
            url={`x-apple-reminderkit://`} // 打开提醒详情
            foregroundStyle={{ dark: "#FF3B30FF", light: "#FF3B30FF" }}
            font={16}
            bold={true}
            padding={{ leading: 16, top: 0, bottom: 0 }}
            buttonStyle="borderless"
            controlSize="regular"
          >
            {`近期`}
          </Link> */}
          <Link
            url={`x-apple-reminderkit://`} // 打开提醒详情
          >
            <HStack
              padding={{ leading: 16, top: 0, bottom: 0 }}
              frame={{ width: 30, alignment: "leading" }}
            >
              <Text
                font={24}
                foregroundStyle={{ dark: "#FFFFFFFF", light: "#000000FF" }}
                frame={{ width: 32 }}
              >
                {day}
              </Text>
              {/* <Spacer minLength={6} /> */}
              <Rectangle
                frame={{ width: 0.5, height: 20 }} // 改成竖线：窄宽度 + 占满高度
                foregroundStyle={{ dark: "#FFFFFFFF", light: "#000000FF" }}
                opacity={0.3}
                padding={{ leading: -4, trailing: -4 }}
              />
              <VStack >
                <Text font={10}
                  foregroundStyle={{ dark: "#FF3B30FF", light: "#FF3B30FF" }}
                  padding={{ leading: -4, trailing: -4 }}
                  frame={{ width: 10, alignment: "leading" }}
                >
                  {weekday}
                </Text>
              </VStack>
            </HStack>
          </Link>
          <Spacer />
          <Button
            title={`${reminders.length}`}
            intent={widgetReloadAll(undefined)}
            foregroundStyle={{ dark: "white", light: "black" }}
            font={24}
            bold={true}
            padding={{ trailing: 16, top: 0, bottom: 0 }}
            buttonStyle="borderless"
            controlSize="regular"
          />
        </HStack>
        {/* 限制显示最多三条提醒 */}
        {reminders.length !== 0 ? displayReminders.map((r, index) => (
          <VStack key={r.identifier} alignment="leading" spacing={6} padding={{ leading: 10, top: index === 0 ? -8 : 0 }}>
            <HStack spacing={4} alignment="center">
              <Button
                padding={{ leading: 12, trailing: 0, top: 2, bottom: 2 }}
                frame={{ width: 24, height: 28 }}
                title=""
                intent={CompleteReminderIntent({ reminderId: r.identifier, isCompleted: r.isCompleted })} // 触发带参数的 AppIntent
                font={24}
                foregroundStyle={{ dark: "#EBEBF599", light: "#3C3C4399" }}
                systemImage="circle.dashed"
                // {records.some(rec => rec.reminderId === r.identifier)
                //   ? "inset.filled.circle.dashed"
                //   : "circle.dashed"}
                buttonStyle="plain"
              />
              <Button
                padding={{ leading: 5, trailing: -4, top: 0 }}
                truncationMode="tail"
                title={`${r.title}`}
                intent={startLiveActivityButton({ title: r.title, identifier: r.identifier, dueDate: String(r.dueDateComponents?.date), notes: r.notes ? r.notes : '' })} // 触发带参数的 AppIntent
                font={15}
                lineLimit={
                  displayReminders.length === 1
                    ? 5 // 如果只有一条提醒，允许更多行
                    : displayReminders.length === 2
                      ? 2 // 如果有两条提醒，允许中等行数
                      : 1
                }
                buttonStyle="plain"
              />
              <Spacer />
              {(
                r.dueDateComponents?.date &&
                (r.dueDateComponents.date.getTime() - now.getTime()) <= 30 * 60 * 1000
              ) ? (
                <Link url={`x-apple-reminderkit://REMCDReminder/${r.identifier}/details`}>
                  <Image
                    font={16}
                    systemName={"clock"}
                    symbolRenderingMode="multicolor"
                    padding={{ leading: -10, trailing: 12 }}
                  />
                </Link>
              ) : null}
            </HStack>
            {/*分割线 */}
            {index < displayReminders.length - 1 ? (
              <HStack padding={{ leading: 32, top: 2, bottom: 2 /* 按钮宽度+间距 */ }}>
                <Rectangle
                  frame={{ height: 0.25 }} // 设置分割线高度
                  stroke={{
                    shapeStyle: { dark: "#AAAAAA", light: "#CCCCCC" },
                    strokeStyle: {
                      dash: [1.5, 1.5]  // 这将创建虚线效果
                    }
                  }}
                  opacity={0.3} // 这里设置透明度
                  padding={{ leading: 0, trailing: 10 }}
                />
                <Spacer />
              </HStack>
            ) : null}
          </VStack>
        ))
          : (
            <VStack alignment="leading" padding={{ leading: 10, top: 0 }}>
              <HStack alignment="center">
                <Text font={15}
                  padding={{ leading: 6, trailing: 5, top: -8, bottom: 5 }}
                  foregroundStyle={{ dark: "#EBEBF599", light: "#3C3C4399" }}
                >❤️没有提醒事项</Text>
                <Spacer />
              </HStack>
              <Spacer />
            </VStack>
          )}
      </VStack>
    )
  } catch (err) {
    console.error("[Widget] 渲染异常:", err)
    return (
      <VStack>
        <Text>加载失败</Text>
      </VStack>
    )
  }
}

(async () => {
  const view = await ReminderWidgetView()
  Widget.present(view, {
    policy: "after",
    date: new Date(Date.now() + 1000 * 60 * 5) // 5分钟后刷新
  })
})()
