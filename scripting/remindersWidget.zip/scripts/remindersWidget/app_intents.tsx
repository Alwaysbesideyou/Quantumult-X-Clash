import { AppIntentManager, AppIntentProtocol, Widget, LiveActivity } from "scripting"
import { getReminders, notification, startLiveActivity } from "./model"
import { config } from "./config"

const fileName = 'App Intents'

export const testNotify = AppIntentManager.register({
    name: "notify",
    protocol: AppIntentProtocol.AppIntent,
    perform: async (content: string) => {
        try {
            notification(fileName, content, config.debug, true)
            HapticFeedback.notificationSuccess()
            Widget.reloadAll()
        } catch (err) {
            notification(fileName, String(err), config.debug, false)
            HapticFeedback.notificationError()
        }
    }
})

export const widgetReloadAll = AppIntentManager.register({
    name: "widgetReloadAll",
    protocol: AppIntentProtocol.AppIntent, // 使用LiveActivityIntent加载很慢,如果只刷新小组件可以使用AppIntent
    perform: async (params: undefined) => {
        try {
            // await clearUnreferencedLiveActivities()
            Widget.reloadAll()
            HapticFeedback.notificationSuccess()
            notification(fileName, "小组件已重载", config.debug, true)
        } catch (err) {
            notification(fileName, `执行小组件重载异常: ${String(err)}`, config.debug, false)
            HapticFeedback.notificationError()
        }
    }
})

export const CompleteReminderIntent = AppIntentManager.register({
    name: "CompleteReminderIntent",
    protocol: AppIntentProtocol.LiveActivityIntent,
    perform: async (params: { reminderId: string; isCompleted: boolean }) => {
        notification(fileName, `执行完成或取消提醒，ID: ${params.reminderId}`, config.debug, true)
        try {
            const reminders = await getReminders({ limit: 10, isCompleted: params.isCompleted })
            const target = reminders.find(r => r.identifier === params.reminderId)
            if (target) {
                target.isCompleted = !params.isCompleted
                notification(fileName, `状态: ${String(target.isCompleted)}`, config.debug, true)
                await target.save() // 保存提醒状态
                const liveActivity = await import("./live_activity") // 动态导入
                if (target.isCompleted) {
                    await liveActivity.endActivityByIdentifier(params.reminderId, config.liveActivityDismissTimeInterval) // 实时活动无法自我终结，秒
                }
                notification(fileName, `提醒已完成: ${target.title}`, config.debug, true)
                HapticFeedback.notificationSuccess()
            } else {
                notification(fileName, `未找到提醒，ID: ${params.reminderId}`, config.debug, false)
                HapticFeedback.notificationError()
            }
        } catch (err) {
            notification(fileName, `完成提醒异常: ${String(err)}`, config.debug, false)
            HapticFeedback.notificationError()
        }
        Widget.reloadAll()
    }
})

export const startLiveActivityButton = AppIntentManager.register({
    name: "startLiveActivityButton",
    protocol: AppIntentProtocol.LiveActivityIntent,
    perform: async (params: { title: string; identifier: string; dueDate: string; notes?: string }) => {
        await startLiveActivity(params)
        Widget.reloadAll()
        notification(fileName, `尝试启动实时活动: ${params.title}`, config.debug, true)
    }
})

