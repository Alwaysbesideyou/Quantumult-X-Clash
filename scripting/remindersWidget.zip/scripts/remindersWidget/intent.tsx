import { Intent, Script } from "scripting"
import { startLiveActivity, notification, getReminders } from "./model"
import { config } from "./config"

const fileName = 'Intent'

async function run() {
    if (Intent.shortcutParameter) {
        const param = Intent.shortcutParameter.value as unknown as {
            body: string
            subtitle: string
            nameOfReminder: string
            classreminders: string
        }

        // 获取该日历所有未完成提醒（不限制条数，或加个大点的 limit）
        let reminders = await getReminders({ limit: 10, isCompleted: false, calendarNames: [param.classreminders], ignoreEndDate: true })

        // 名称匹配（忽略大小写和前后空格）
        const isReminder = (reminder: Reminder): boolean =>
            reminder.title.trim().toLowerCase() === param.nameOfReminder.trim().toLowerCase()

        const r = reminders.find(isReminder)
        if (r) {
            const identifier = r.identifier

            notification(
                param.subtitle,
                param.body,
                true,
                true,
                {
                    title: 'Alertpilot',
                    interruptionLevel: "timeSensitive",
                    userInfo: { identifier },
                    avoidRunningCurrentScriptWhenTapped: false,
                    customUI: false,
                    actions: [{
                        title: "修改提醒事项",
                        scriptName: Script.name,
                        parameters: { url: `x-apple-reminderkit://REMCDReminder/${identifier}/details` }
                    },
                    {
                        title: "启动实时活动",
                        scriptName: Script.name,
                        parameters: { title: r.title, identifier, dueDate: String(r.dueDateComponents?.date), notes: r.notes ?? '', startLiveActivity: true }
                    },
                    ]
                }
            )
        } else { notification(fileName, `未找到匹配的提醒: ${param.nameOfReminder}`, config.debug, false) }
    }

    Script.exit(Intent.text("处理完成"))
    return
}

run()
